#coding=utf-8
import json

import Api
# Api.authPersonMobile3()
# Api.authCompanyMobile3()
# Api.authCaptchaVerify()
# Api.addPersonalUser()
# Api.addEnterpriseUser()
Api.getUser()
# Api.userCreateSeal()
# Api.createContract()
# Api.addSigner()
# Api.downloadContract()













## result = Api.downloadContract()
# respBody = json.loads(result)
# if respBody['code'] == 100000 and respBody['data'] != "":
#     outPath = r"C:\Users\PC\Desktop\pythonsdk\contract.pdf" # 注意文件类型响应参数fileType：1为zip
#     Api.writeToDisk(respBody['data']['data'], outPath)
#     print("1111")
# else:
#     print("0000")

